// #include <gflags/gflags.h>
// #include <glog/logging.h>

#include "ch7/direct_ndt_lo.h"
#include "ch7/ndt_3d.h"
#include "../lidar_utils.h"
#include "iostream"

#include <pcl/point_cloud.h>
#include <pcl/point_types.h>

#include <iostream>
#include <pcl/point_types.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/io/pcd_io.h>
#include <vector>
#include <algorithm>
#include <filesystem>

using namespace std;

namespace fs = std::filesystem;

int main(int argc, char** argv) {

    bool FLAGS_use_pcl_ndt=false;
    bool FLAGS_use_ndt_nearby_6=false;
    bool FLAGS_display_map=true;

    DirectNDTLO::Options options; //class DirectNDTLO is defined in direct_ndt_lo.h
    options.use_pcl_ndt_ = FLAGS_use_pcl_ndt;
    cout<<"------options.use_pcl_ndt_ ="<<options.use_pcl_ndt_ <<endl;
    options.ndt3d_options_.nearby_type_ = FLAGS_use_ndt_nearby_6 ? Ndt3d::NearbyType::NEARBY6 : Ndt3d::NearbyType::CENTER;
    options.display_realtime_cloud_ = FLAGS_display_map;
    DirectNDTLO ndt_lo(options);

    std::string path = "./pcd_files"; // 替换为你的目录路径
    std::vector<fs::path> files;
 
    for (const auto& entry : fs::directory_iterator(path)) {
        if (fs::is_regular_file(entry.status())) {
            files.push_back(entry.path());
        }
    }
 
    std::sort(files.begin(), files.end());
    std::string file_name = "Hello"; 
    pcl::PointCloud<pcl::PointXYZI>::Ptr laserCloudIn(new pcl::PointCloud<pcl::PointXYZI>);
    for (const auto& file: files) {
      SE3 pose;
      std::cout << file << std::endl;
      file_name=file.string();   //convert type of file into string type
      // std::cout << file_name.substr(12,24)<< std::endl;
      pcl::io::loadPCDFile<pcl::PointXYZI> (file, *laserCloudIn);
      // pcl::io::savePCDFile<pcl::PointXYZI> ("./test/"+file_name.substr(12,24), *laserCloudIn);

      // 把点云从ros格式转到pcl的格式
      //   pcl::fromROSMsg(*msg, *laserCloudIn);
      // pcl::io::savePCDFile("/home/smart/Workspace/slamch7_ndtlo12/test_frame.pcd", *laserCloudIn);
      // cout<<"**********************---length of point cloud"<< (*laserCloudIn).points.size()<<endl;
      cout<<"--------pose="<<pose.matrix()<<endl;
      // ndt_lo.AddCloud(VoxelCloud(PointCloud2ToCloudPtr(msg)), pose);
      ndt_lo.AddCloud(VoxelCloud(laserCloudIn), pose);
    }
    return 0;
}
