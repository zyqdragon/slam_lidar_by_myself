ubuntu 20.04
set(CMAKE_CXX_STANDARD 17)  # C++ 17
option(BUILD_WITH_UBUNTU1804 OFF)
eigen 3
sophus
pcl
opencv

run as follows:
cd build
cmake ..
make
./test_ndt
