# -*- coding: utf-8 -*-
import open3d as o3d
import numpy as np
import os
import copy

FOR1 = o3d.geometry.TriangleMesh.create_coordinate_frame(size=0.5, origin=[0, 0, 0])
pcd1 = o3d.io.read_point_cloud("rabbit2.pcd")
pcd2=copy.deepcopy(pcd1)
pcd1.translate((0.06,0.3,0),relative=True)
# cl,ind = pcd.remove_radius_outlier(nb_points,radius=1)
# pcd = pcd.select_by_index(ind)

#mesh_r = mesh.rotate(R, center=(0, 0, 0))

o3d.io.write_point_cloud("./rabbit_target2.pcd", pcd1)
vis = o3d.visualization.Visualizer()
vis.create_window()
#将点云添加至visualizer
vis.add_geometry(FOR1)
vis.add_geometry(pcd1)
vis.add_geometry(pcd2)
vis.get_render_option().point_size=2
vis.get_render_option().show_coordinate_frame=False
vis.get_render_option().background_color = np.asarray([0, 0, 0])  # you can set the bg color
#让visualizer渲染点云
vis.poll_events()
vis.update_renderer()
vis.run()

#https://blog.csdn.net/skycol/article/details/127429843
