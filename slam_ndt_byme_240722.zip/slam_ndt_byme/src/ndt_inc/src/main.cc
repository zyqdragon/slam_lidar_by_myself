#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl_conversions/pcl_conversions.h>
#include "incremental_ndt_lo.h"
#include <deque>
#include <nav_msgs/Odometry.h>
#include <nav_msgs/Path.h>

std::string frame_id{"camera_init"};
ros::Subscriber sub1_;
ros::Publisher pub_now_;

IncrementalNDTLO::Options options;
pcl::VoxelGrid<PointType> downsample;

nav_msgs::Path path;
nav_msgs::Odometry odomAftMapped;
geometry_msgs::PoseStamped msg_body_pose;

template<typename T>
void set_posestamp(T & out, SE3& transform);

void publish_path(const ros::Publisher pubPath, const SE3 &transform);

IncrementalNDTLO ndt_lo;
std::deque<PointCloudType> all_clouds;

template<typename T>
void set_posestamp(T & out, const SE3& transform)
{   
    Eigen::Matrix3d rotation = transform.so3().matrix();  
    Eigen::Quaterniond quaternion(rotation); 

    // Eigen::Vector4d q = transform.so3().coeffs();
    Eigen::Vector3d t = transform.translation();  
    out.pose.position.x = t(0);
    out.pose.position.y = t(1);
    out.pose.position.z = t(2);
    out.pose.orientation.x = quaternion.x();
    out.pose.orientation.y = quaternion.y();
    out.pose.orientation.z = quaternion.z();
    out.pose.orientation.w = quaternion.w();
    
}


void publish_path(const ros::Publisher pubPath, const SE3 &transform)
{
    set_posestamp(msg_body_pose, transform);
    msg_body_pose.header.stamp = ros::Time::now();
    msg_body_pose.header.frame_id = frame_id;

    /*** if path is too large, the rvis will crash ***/
    static int jjj = 0;
    jjj++;
    if (jjj % 10 == 0) 
    {
        path.poses.push_back(msg_body_pose);
        path.header.frame_id = frame_id;
        path.header.stamp = ros::Time::now();
        // ROS_INFO("path pose size is : %d", path.poses.size());
        pubPath.publish(path);
        // ROS_WARN("publish path success!!");
    }
}




void pcl_cb(const sensor_msgs::PointCloud2ConstPtr& input_msg){
  auto t1 = std::chrono::high_resolution_clock::now();
  CloudPtr pointcloud (new PointCloudType());

  pcl::fromROSMsg(*input_msg, *pointcloud);
  CloudPtr pointcloud_ds (new PointCloudType());


  downsample.setInputCloud(pointcloud);
  downsample.filter(*pointcloud_ds);
  all_clouds.push_back(*pointcloud_ds);
  auto t2 = std::chrono::high_resolution_clock::now();

  std::cout << "[CallBack] filtered time: ------->" 
  << std::chrono::duration_cast<std::chrono::milliseconds>(t2 - t1).count() << " ms"<< std::endl;


}

int main(int argc, char ** argv){
  ros::init(argc, argv, "ndt_node");
  ros::NodeHandle nh("~");
  options.ndt3d_options_.nearby_type_ = IncNdt3d::NearbyType::CENTER;
  ndt_lo = IncrementalNDTLO(options);
  // downsample.setLeafSize(0.1, 0.1, 0.1);
  downsample.setLeafSize(0.3, 0.3, 0.3);

  pub_now_ = nh.advertise<sensor_msgs::PointCloud2>("/ndt_point", 10);
  // sub1_ = nh.subscribe< sensor_msgs::PointCloud2>("/os_cloud_node/points", 10, &pcl_cb);
  sub1_ = nh.subscribe< sensor_msgs::PointCloud2>("/avia_3421/livox/lidar", 10, &pcl_cb);


  ros::Publisher pubOdomAftMapped = nh.advertise<nav_msgs::Odometry> 
            ("/Odometry", 100000);
  ros::Publisher pubPath          = nh.advertise<nav_msgs::Path> 
            ("/path", 100000);
  while (ros::ok()){
    ros::spinOnce();
    if (all_clouds.size() == 0) continue;
    CloudPtr pointcloud_ds(new PointCloudType);
    CloudPtr tf_pointcloud(new PointCloudType);

    pointcloud_ds->points = all_clouds.front().points;
    all_clouds.pop_front();

    SE3 guess_pose;
    auto t3 = std::chrono::high_resolution_clock::now();
    ndt_lo.AddCloud(pointcloud_ds, guess_pose);
    auto t4 = std::chrono::high_resolution_clock::now();
    std::cout << "[MAIN] process time: ------->" 
    << std::chrono::duration_cast<std::chrono::milliseconds>(t4 - t3).count() << " ms"<< std::endl;



    pcl::transformPointCloud(*pointcloud_ds, *tf_pointcloud, guess_pose.matrix().cast<float>());
    sensor_msgs::PointCloud2 send_msg;
    pcl::toROSMsg(*tf_pointcloud, send_msg);
    send_msg.header.frame_id = frame_id;
    send_msg.header.stamp  = ros::Time::now();
    send_msg.width = tf_pointcloud->points.size();
    pub_now_.publish(send_msg);

    publish_path(pubPath, guess_pose);
  }
  return 0;



}