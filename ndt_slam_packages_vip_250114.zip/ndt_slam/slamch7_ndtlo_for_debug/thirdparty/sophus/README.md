# sophus

sophus for SE(3) and SO(3)