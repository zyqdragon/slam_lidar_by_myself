
#include <iostream>
#include <pcl/point_types.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/io/pcd_io.h>
#include <vector>
#include <algorithm>
#include <filesystem>

namespace fs = std::filesystem;
 
int main (int argc, char** argv) {
  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ>);

  std::string path = "./pcd_files"; // 替换为你的目录路径
  std::vector<fs::path> files;
 
    for (const auto& entry : fs::directory_iterator(path)) {
        if (fs::is_regular_file(entry.status())) {
            files.push_back(entry.path());
        }
    }
 
    std::sort(files.begin(), files.end());
    std::string file_name = "Hello"; 
    for (const auto& file: files) {
      std::cout << file << std::endl;
      file_name=file.string();   //convert type of file into string type
      // std::cout << file_name.substr(12,24)<< std::endl;
      pcl::io::loadPCDFile<pcl::PointXYZ> (file, *cloud);
      pcl::io::savePCDFile<pcl::PointXYZ> ("./test/"+file_name.substr(12,24), *cloud);

    }
 
  return 0;
}
