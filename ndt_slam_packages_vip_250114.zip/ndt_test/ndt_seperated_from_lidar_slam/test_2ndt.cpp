#include <pcl/common/transforms.h>
#include <pcl/io/pcd_io.h>
#include <pcl/registration/icp.h>
#include <pcl/registration/ndt.h>

#include "ndt_3d.h"
//#include "common/point_cloud_utils.h"
//#include "common/sys_utils.h"
#include <iostream>
// #include "common/point_types.h"
// #include "common/eigen_types.h"
#include "point_types.h"
#include "eigen_types.h"

using namespace std;

int main(int argc, char** argv) {
    // sad::CloudPtr source(new sad::PointCloudType), target(new sad::PointCloudType);
    CloudPtr source(new PointCloudType), target(new PointCloudType);
    // pcl::io::loadPCDFile(fLS::FLAGS_source, *source);
    // pcl::io::loadPCDFile(fLS::FLAGS_target, *target);
    pcl::io::loadPCDFile("./data/ch7/EPFL/pcd_src.pcd", *source);
    pcl::io::loadPCDFile("./data/ch7/EPFL/pcd_tar.pcd", *target);
    bool success;

    cout<<"-----start of NDT-----------------"<<endl;
    Ndt3d::Options options;
    options.voxel_size_ = 0.5;
    options.remove_centroid_ = true;
    options.nearby_type_ = Ndt3d::NearbyType::CENTER;
    Ndt3d ndt(options);
    ndt.SetSource(source);
    ndt.SetTarget(target);
    // ndt.SetGtPose(gt_pose);
    SE3 pose;
    cout<<"-----pose1-----------------"<<pose.matrix()<<endl;
    success = ndt.AlignNdt(pose);
    cout<<"-----pose2-----------------"<<endl<<pose.matrix()<<endl;
    if (success) 
    {
    // LOG(INFO) << "ndt align success, pose: " << pose.so3().unit_quaternion().coeffs().transpose() << ", "
    //         << pose.translation().transpose();
    // sad::CloudPtr source_trans(new sad::PointCloudType);
    CloudPtr source_trans(new PointCloudType);
    pcl::transformPointCloud(*source, *source_trans, pose.matrix().cast<float>());
    // sad::SaveCloudToFile("./data/ch7/ndt_trans.pcd", *source_trans);
    pcl::io::savePCDFileASCII("./ndt_source_trans.pcd", *source_trans);
    } 
    else
    {
        // LOG(ERROR) << "align failed.";
        cout<<"----align failed-----------"<<endl;
    }
    cout<<"----end of NDT-----------------"<<endl;

    cout<<"----start of PCL NDT-----------------"<<endl;
    pcl::NormalDistributionsTransform<PointType, PointType> ndt_pcl;
    ndt_pcl.setInputSource(source);
    ndt_pcl.setInputTarget(target);
    ndt_pcl.setResolution(0.5);
    // sad::CloudPtr output_pcl(new sad::PointCloudType);
    CloudPtr output_pcl(new PointCloudType);
    ndt_pcl.align(*output_pcl);
    SE3f T = SE3f(ndt_pcl.getFinalTransformation());
    // LOG(INFO) << "pose from ndt pcl: " << T.so3().unit_quaternion().coeffs().transpose() << ", "
    //         << T.translation().transpose() << ', trans: ' << ndt_pcl.getTransformationProbability();
    // sad::SaveCloudToFile("./data/ch7/pcl_ndt_trans.pcd", *output_pcl);
    pcl::io::savePCDFileASCII("./pcl_ndt_source_trans.pcd", *output_pcl);
    // LOG(INFO) << "score: " << ndt_pcl.getTransformationProbability();

    // 计算GT pose差异
    // double pose_error = (gt_pose.inverse() * T.cast<double>()).log().norm();
    // LOG(INFO) << "NDT PCL pose error: " << pose_error;
    cout<<"----end of PCL NDT-----------------"<<endl;
    return 0;
}