# -*- coding: utf-8 -*-
import open3d as o3d
import numpy as np
import os

FOR1 = o3d.geometry.TriangleMesh.create_coordinate_frame(size=0.5, origin=[0, 0, 0])
pcd1 = o3d.io.read_point_cloud("./EPFL/pcd_src.pcd")
pcd2 = o3d.io.read_point_cloud("./EPFL/pcd_tar.pcd")
pcd3 = o3d.io.read_point_cloud("./EPFL/pcd_src.pcd")
pcd2.paint_uniform_color([0, 1, 0])
pcd1.paint_uniform_color([1, 0, 0])
pcd3.paint_uniform_color([0, 0, 1])

#pcd1.translate((2,0,0),relative=True)
#o3d.io.write_point_cloud("./transformed_pcd.pcd", pcd1)

vis = o3d.visualization.Visualizer()
vis.create_window()
#将点云添加至visualizer
vis.add_geometry(FOR1)
vis.add_geometry(pcd1)
vis.add_geometry(pcd2)
vis.add_geometry(pcd3)
#vis.add_geometry(pcd3)
vis.get_render_option().point_size=2
vis.get_render_option().show_coordinate_frame=False
vis.get_render_option().background_color = np.asarray([0, 0, 0])  # you can set the bg color
#让visualizer渲染点云
vis.poll_events()
vis.update_renderer()
vis.run()
