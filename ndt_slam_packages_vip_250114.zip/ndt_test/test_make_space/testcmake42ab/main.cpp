#include <swap.h>
int main() {
    swap obj_ab(2,3);
    obj_ab.print_info();
    obj_ab.run();
    obj_ab.print_info();
}