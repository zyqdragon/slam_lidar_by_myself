#pragma once
#include <iostream> 
class swap
{
private:
    int a, b;
public:
    swap(int a, int b)
    {
        this->a = a;
        this->b = b;
    }
    void run();
    void print_info();
};
