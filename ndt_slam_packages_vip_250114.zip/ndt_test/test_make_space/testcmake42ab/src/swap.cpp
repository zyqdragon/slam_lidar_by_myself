#include "swap.h"
void swap::run() {
    int temp;
    temp = a;
    a = b;
    b = temp;
}
 
void swap::print_info() {
    std::cout << "a = " << a << std::endl;
    std::cout << "b = " << b << std::endl;
}