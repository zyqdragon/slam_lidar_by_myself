#include <iostream>
#include "test.cpp"
using namespace std;

// int test(int a,int b)
// {
//   std::cout<< "******hello world, I am a genius! Good Test!******* " << endl;
//   return a+b;
// }

int main()
{
  int b;
  test();
  cout<<"---b="<<b<<endl;
  std::cout<< "hello world, I am a genius! Good Test! " << endl;
  return 0;
}
