#include <iostream>
using namespace std;
void test()
{
  cout<< "******hello world, I am a genius! Good Test!******* " << endl;
}
