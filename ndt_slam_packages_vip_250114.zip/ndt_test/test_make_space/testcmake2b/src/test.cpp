#include <iostream>
#include <test.h>
using namespace std;

int test(int a,int b)
{
  std::cout<< "******hello world, I am a genius! Good Test!******* " << endl;
  return a+b;
}
