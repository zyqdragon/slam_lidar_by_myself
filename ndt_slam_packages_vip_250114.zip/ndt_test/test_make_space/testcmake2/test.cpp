#include <iostream>
using namespace std;
int test()
{
  std::cout<< "******hello world, I am a genius! Good Test!******* " << endl;
  return 8;
}
