// #include <gflags/gflags.h>
// #include <glog/logging.h>

#include <pcl/common/transforms.h>
#include <pcl/io/pcd_io.h>
#include <pcl/registration/icp.h>
#include <pcl/registration/ndt.h>

#include "ch7/ndt_3d.h"
#include "ch7/point_cloud_utils.h"
#include "ch7/sys_utils.h"
#include <iostream>

using namespace std;

DEFINE_string(source, "./data/ch7/EPFL/kneeling_lady_source.pcd", "第1个点云路径");
DEFINE_string(target, "./data/ch7/EPFL/kneeling_lady_target.pcd", "第2个点云路径");
DEFINE_string(ground_truth_file, "./data/ch7/EPFL/kneeling_lady_pose.txt", "真值Pose");

int main(int argc, char** argv) {
    // google::InitGoogleLogging(argv[0]);
    // FLAGS_stderrthreshold = google::INFO;
    // FLAGS_colorlogtostderr = true;
    // google::ParseCommandLineFlags(&argc, &argv, true);
    cout<<"----argv[0]="<<argv[0]<<endl;

    // EPFL 雕像数据集：./ch7/EPFL/aquarius_{sourcd.pcd, target.pcd}，真值在对应目录的_pose.txt中
    // EPFL 模型比较精细，配准时应该采用较小的栅格

    cout<<"----------FLAGS_ground_truth_file="<<FLAGS_ground_truth_file<<endl;

    std::ifstream fin(FLAGS_ground_truth_file);
    SE3 gt_pose;
    if (fin) {
        double tx, ty, tz, qw, qx, qy, qz;
        fin >> tx >> ty >> tz >> qw >> qx >> qy >> qz;
        fin.close();
        gt_pose = SE3(Quatd(qw, qx, qy, qz), Vec3d(tx, ty, tz));
    }
    cout<<"---new--gt_pose="<<gt_pose.matrix()<<endl;

    sad::CloudPtr source(new sad::PointCloudType), target(new sad::PointCloudType);
    pcl::io::loadPCDFile(fLS::FLAGS_source, *source);
    // pcl::io::loadPCDFile(fLS::FLAGS_target, *target);
    pcl::io::loadPCDFile(fLS::FLAGS_target, *target);

    bool success;

    cout<<"-----start of NDT-----------------"<<endl;
    sad::Ndt3d::Options options;
    options.voxel_size_ = 0.5;
    options.remove_centroid_ = true;
    options.nearby_type_ = sad::Ndt3d::NearbyType::CENTER;
    sad::Ndt3d ndt(options);
    ndt.SetSource(source);
    ndt.SetTarget(target);
    // ndt.SetGtPose(gt_pose);
    SE3 pose;
    cout<<"-----pose1-----------------"<<pose.matrix()<<endl;
    success = ndt.AlignNdt(pose);
    cout<<"-----pose2-----------------"<<endl<<pose.matrix()<<endl;
    if (success) 
    {
    // LOG(INFO) << "ndt align success, pose: " << pose.so3().unit_quaternion().coeffs().transpose() << ", "
    //         << pose.translation().transpose();
    cout<< "ndt align success, pose: " << pose.so3().unit_quaternion().coeffs().transpose() << ", " << pose.translation().transpose();
    sad::CloudPtr source_trans(new sad::PointCloudType);
    pcl::transformPointCloud(*source, *source_trans, pose.matrix().cast<float>());
    // sad::SaveCloudToFile("./data/ch7/ndt_trans.pcd", *source_trans);
    pcl::io::savePCDFileASCII("./ndt_source_trans.pcd", *source_trans);
    } 
    else
    {
        // LOG(ERROR) << "align failed.";
        cout<<"-------align failed-----------"<<endl;
    }
    cout<<"----new1-end of NDT-----------------"<<endl;

    return 0;
}